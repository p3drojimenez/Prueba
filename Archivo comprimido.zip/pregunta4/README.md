# vjs-test

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).


Pasos: 
1. npm install
2. npm run serve
3. En el navegador, entra en la url que te indica cuando ejecutas el paso 2.
4. En src/App.vue, reemplaza el componente HelloWorld por el componente Pridatect para seguir el enunciado.
