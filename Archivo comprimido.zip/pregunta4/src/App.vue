<template>
  <div id="app">
    <Pridatect/>
  </div>
</template>

<script>
  import HelloWorld from './components/HelloWorld.vue'
  import Pridatect from './components/Pridatect.vue'
  import 'vuetify/dist/vuetify.css'

export default {  
  name: 'app',
  components: {
    HelloWorld,
    Pridatect
  }
}
</script>

